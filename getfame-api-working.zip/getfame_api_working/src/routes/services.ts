import { Router } from 'express';
import { z } from 'zod';
import { fetchServices, Service } from '../jap.js';
import { TTLCache } from '../utils/cache.js';
import { ENV } from '../env.js';

const router = Router();
const cache = new TTLCache<Service[]>(ENV.SERVICES_TTL_MS);

const QuerySchema = z.object({
  social: z.string().optional(),
  q: z.string().optional(),
});

function matchesFilter(s: Service, social?: string, q?: string) {
  const hay = `${s.category} ${s.name} ${s.type}`.toLowerCase();
  const socialMatch = !social ? true : hay.includes(social.toLowerCase());
  const qMatch = !q ? true : hay.includes(q.toLowerCase());
  return socialMatch && qMatch;
}

router.get('/', async (req, res, next) => {
  try {
    const parsed = QuerySchema.parse(req.query);
    const cacheKey = 'services';
    let services = cache.get(cacheKey);
    if (!services) {
      services = await fetchServices();
      cache.set(cacheKey, services);
    }
    const filtered = services
      .filter(s => matchesFilter(s, parsed.social, parsed.q))
      .map(s => ({
        id: s.service,
        name: s.name,
        category: s.category,
        type: s.type,
        rate: Number(s.rate),
        min: Number(s.min),
        max: Number(s.max),
        refill: Boolean(s.refill),
        cancel: Boolean(s.cancel),
      }));
    res.json({ services: filtered, count: filtered.length, cached: true });
  } catch (err) { next(err); }
});

router.get('/raw', async (_req, res, next) => {
  try {
    const services = await fetchServices();
    res.json(services);
  } catch (err) { next(err); }
});

export default router;
